import importlib

packages = ['pandas', 'numpy', 'seaborn', 'matplotlib', 'ucimlrepo']

for pkg in packages:
    try:
        mod = importlib.import_module(pkg)
        version = getattr(mod, '__version__', 'Versión no disponible')
        print(f"{pkg} ✅ instalado (versión: {version})")
    except ImportError:
        print(f"{pkg} ❌ NO está instalado")